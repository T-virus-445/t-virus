#T-virus ela instala ferramentas de Pentest  no seu ubuntu sem quebrar o Sistema  Ubuntu 

#como usar a ferramenta

unzip t-virus.zip 

cd t-virus/

chmod +x t-virus.py

#Modo De executar a Ferramenta 

python t-virus.py OU >> ./t-virus.py 

#navegar no script 

1 adicione o repositorio depois atualize 

1) Add T-virus repositorio E Update 
2) Ver Categorias 
3) Instalar classicmenu indicator
4) Install T-virus menu
5) Help

t-virus> coloque o numero qual vc deseja

#Pra instalar uma ferramenta Use o numero que  vc deseja 


=+[ Information Gathering

 1) acccheck					30) lbd
 2) ace-voip					31) Maltego Teeth
 3) Amap					32) masscan
 4) Automater					33) Metagoofil
 5) bing-ip2hosts				34) Miranda
 6) braa					35) Nmap
 7) CaseFile					36) ntop
 8) CDPSnarf					37) p0f
 9) cisco-torch					38) Parsero
10) Cookie Cadger				39) Recon-ng
11) copy-router-config				40) SET
12) DMitry					41) smtp-user-enum
13) dnmap					42) snmpcheck
14) dnsenum					43) sslcaudit
15) dnsmap					44) SSLsplit
16) DNSRecon					45) sslstrip
17) dnstracer					46) SSLyze
18) dnswalk					47) THC-IPV6
19) DotDotPwn					48) theHarvester
20) enum4linux					49) TLSSLed
21) enumIAX					50) twofi
22) exploitdb					51) URLCrazy
23) Fierce					52) Wireshark
24) Firewalk					53) WOL-E
25) fragroute					54) Xplico
26) fragrouter					55) iSMTP
27) Ghost Phisher				56) InTrace
28) GoLismero					57) hping3
29) goofile

0) Install all Information Gathering tools
				 
						
coloque um numero para poder instalar a ferramenta .

t-virus >1

#Não esqueça de remover o repositorio. Projeto está em desenvolvimento falta muita coisa. mas esta funcionando bemm. Obrigado a todos

Facebook> https://web.facebook.com/groups/chernobylhackers/

Git> https://github.com/T-virus-445 

Youtube>> https://www.youtube.com/watch?v=yivrXA7l6Hk&feature=youtu.be 

obrigado a todos MEU AMOR LUANA minha Hackudaaa

Obrigado Guilherme. e Leooo 


Repositorio usado no scritp 

#cyborg >> 

cyborg linuz

deb http://ppa.launchpad.net/cyborg-hawk/stable/ubuntu trusty main 
deb-src http://ppa.launchpad.net/cyborg-hawk/stable/ubuntu trusty main

sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys E57D746E
apt-get update 

# vc pode usar o repositorio do backbox linux no seu sistema ubuntu. 

backbox

deb http://ppa.launchpad.net/backbox/four/ubuntu  trusty main
deb-src http://ppa.launchpad.net/backbox/four/ubuntu  trusty main

#Faltaaaa 47 ferramentas ainda. pra pode adicionar no projeto. mas esta funcionando de boaa. 
se der adicione o repositorio do backbox. obrigado 
